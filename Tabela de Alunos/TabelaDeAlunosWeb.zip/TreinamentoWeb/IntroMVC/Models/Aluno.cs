﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TreinamentoWeb.Models
{
    public class Aluno
    {
        public string Nome { get; set; }
        public string Matricula { get; set; }
    }
}